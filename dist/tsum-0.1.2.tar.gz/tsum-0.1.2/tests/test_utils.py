#from tensor_uq_etc import sys_fun_sum
import tsum.utils as utils
